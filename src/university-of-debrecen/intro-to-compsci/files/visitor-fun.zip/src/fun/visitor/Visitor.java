package fun.visitor;

/**
 * Node-ok feldolgozására képes osztályokat összefogó interfész.
 *
 * Minden metódusa rendelkezik egy üres default implementációval, hogy
 * azon osztályok, melyek nem szeretnének foglalkozni az összes különböző
 * Node-dal, ne teljenek meg felesleges metódusokkal.
 * Ezen felül, ez elősegíti az evolúciót is: ha hozzáadunk egy új, X típusú
 * Node-ot, és vele egy visitX metódust, akkor az üres default implementációnak
 * hála nem törnek el az interfészt megvalósító osztályok.
 */
public interface Visitor {
    default void visitLiteral(Literal literal) {
    }

    default void visitAddition(Addition addition) {
    }

    default void visitMultiplication(Multiplication multiplication) {
    }
}
