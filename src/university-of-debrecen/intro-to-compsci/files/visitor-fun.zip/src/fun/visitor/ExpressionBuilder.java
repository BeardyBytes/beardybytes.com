package fun.visitor;

import static java.util.Objects.requireNonNull;

/**
 * A csomópontokból álló kifejezések felépítését megkönnyítő osztály.
 */
public class ExpressionBuilder {
    /**
     * Privát konstruktor, nem lehet példányosítani kívülről.
     */
    private ExpressionBuilder() {
        // No-op
    }

    public static Literal literal(final int value) {
        return new Literal(value);
    }

    public static Addition addition(final Node left, final Node right) {
        requireNonNull(left);
        requireNonNull(right);

        return new Addition(left, right);
    }

    public static Multiplication multiplication(final Node left, final Node right) {
        requireNonNull(left);
        requireNonNull(right);

        return new Multiplication(left, right);
    }
}
