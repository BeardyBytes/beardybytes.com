package fun.visitor;

/**
 * Konkrét, literális értéket tartalmazó csomópont. Például, ha van
 * egy összeadásunk, "2 + 3", akkor ez két fun.visitor.Literal fun.visitor.Node-ot tartalmaz,
 * "2" és "3" értékekkel.
 */
public class Literal implements Node {
    /**
     * A literál tényleges értéke.
     */
    private final int value;

    public Literal(final int value) {
        this.value = value;
    }

    @Override
    public void visit(Visitor visitor) {
        visitor.visitLiteral(this);
    }

    public int getValue() {
        return value;
    }
}
