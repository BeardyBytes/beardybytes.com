package fun.visitor;

import static java.util.Objects.requireNonNull;

/**
 * Összeadást reprezentáló fun.visitor.Node.
 */
public class Addition implements Node {
    /**
     * Az összeadás bal oldalán szereplő kifejezés.
     */
    private final Node left;

    /**
     * Az összeadás jobb oldalán szereplő kifejezés.
     */
    private final Node right;

    public Addition(final Node left, final Node right) {
        this.left = requireNonNull(left);
        this.right = requireNonNull(right);
    }

    @Override
    public void visit(Visitor visitor) {
        visitor.visitAddition(this);
    }

    public Node getLeft() {
        return left;
    }

    public Node getRight() {
        return right;
    }
}
