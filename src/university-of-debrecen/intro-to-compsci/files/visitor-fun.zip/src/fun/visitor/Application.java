package fun.visitor;

import static fun.visitor.ExpressionBuilder.addition;
import static fun.visitor.ExpressionBuilder.literal;
import static fun.visitor.ExpressionBuilder.multiplication;

public class Application {
    public static void main(String[] args) {
        final Node node = addition(
                literal(2),
                multiplication(
                        literal(3),
                        literal(4)
                )
        );

        System.out.println("2 + (3 * 4) = " + EvaluationVisitor.evaluateNode(node));
        System.out.println("A szorzások száma: " + CountMultiplications.inNode(node));
    }
}

