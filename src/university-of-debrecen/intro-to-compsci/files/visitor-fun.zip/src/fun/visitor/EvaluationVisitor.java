package fun.visitor;

import java.util.Stack;

import static java.util.Objects.requireNonNull;

/**
 * Kiértékel egy adott Node-ot, végigmenve a gyermekein.
 *
 * A kiértékeléshez egy vermet használ, arra pakolja fel a gyermekekből
 * kiszámolt értékeket. A végső érték a verem egyetlen elemeként áll elő,
 * a fabejárás végén.
 */
class EvaluationVisitor implements Visitor {
    private final Stack<Integer> evaluationStack = new Stack<>();

    private EvaluationVisitor() {
        // No-op.
    }

    public static int evaluateNode(final Node node) {
        requireNonNull(node);

        final EvaluationVisitor visitor = new EvaluationVisitor();

        node.visit(visitor);

        return visitor.evaluationStack.pop();
    }

    @Override
    public void visitLiteral(final Literal literal) {
        evaluationStack.push(literal.getValue());
    }

    @Override
    public void visitAddition(final Addition addition) {
        // Összeadásnál mindegy, milyen sorrendben számoljuk
        // a bal és a jobb oldalt, azonban kivonás esetén például
        // már nem lenne mindegy.
        addition.getLeft().visit(this);
        addition.getRight().visit(this);

        evaluationStack.push(evaluationStack.pop() + evaluationStack.pop());
    }

    @Override
    public void visitMultiplication(final Multiplication multiplication) {
        multiplication.getLeft().visit(this);
        multiplication.getRight().visit(this);

        evaluationStack.push(evaluationStack.pop() * evaluationStack.pop());
    }
}
