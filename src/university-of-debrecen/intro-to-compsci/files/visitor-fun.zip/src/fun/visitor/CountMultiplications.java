package fun.visitor;

import static java.util.Objects.requireNonNull;

class CountMultiplications implements Visitor {
    private int count = 0;

    private CountMultiplications() {
        // No-op.
    }

    public static int inNode(final Node node) {
        requireNonNull(node);

        final CountMultiplications visitor = new CountMultiplications();

        node.visit(visitor);

        return visitor.count;
    }

    @Override
    public void visitAddition(Addition addition) {
        addition.getLeft().visit(this);
        addition.getRight().visit(this);
    }

    @Override
    public void visitMultiplication(Multiplication multiplication) {
        count++;
        multiplication.getLeft().visit(this);
        multiplication.getRight().visit(this);
    }
}
