package fun.visitor;

/**
 * Egy tetszőleges csomópont a faszerkezetben.
 */
public interface Node {
    /**
     * A fun.visitor.Node feldolgozása az átadott fun.visitor.Visitor segítségével.
     *
     * @param visitor A visitor, aki feldolgozza a fun.visitor.Node-ot. Nem lehet {@code null}.
     */
    void visit(Visitor visitor);
}
