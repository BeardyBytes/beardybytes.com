package fun.visitor;

import static java.util.Objects.requireNonNull;

/**
 * Szorzást reprezentáló fun.visitor.Node.
 */
public class Multiplication implements Node {
    /**
     * A szorzás bal oldalán szereplő kifejezés.
     */
    private final Node left;

    /**
     * A szorzás jobb oldalán szereplő kifejezés.
     */
    private final Node right;

    public Multiplication(final Node left, final Node right) {
        this.left = requireNonNull(left);
        this.right = requireNonNull(right);
    }

    @Override
    public void visit(Visitor visitor) {
        visitor.visitMultiplication(this);
    }

    public Node getLeft() {
        return left;
    }

    public Node getRight() {
        return right;
    }
}
